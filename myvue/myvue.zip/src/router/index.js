import { createRouter, createWebHistory } from 'vue-router'
import Home from '@/views/Home.vue'
import Login from '@/views/Login.vue'
import Register from '@/views/Register.vue'
import ShopCart from '@/views/ShopCart.vue'

import SelectedGoods from '@/components/Home/NavContent/Goods/SelectedGoods'
import AllGoods from '@/components/Home/NavContent/Goods/AllGoods'



const routes = [
  {
    path: '/',
    redirect:'/Home',
  },
  {
    path: '/Home',
    name: 'Home',
    component: Home,
    children:[
        {
            path:'SelectedGoods',
            component:SelectedGoods
        },
        {
            path:'AllGoods',
            component:AllGoods
        }
    ]
  },
  {
    path: '/ShopCart',
    name: 'ShopCart',
    component: ShopCart,
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  {
    path: '/Register',
    name: 'Register',
    component: Register
  },
 
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
