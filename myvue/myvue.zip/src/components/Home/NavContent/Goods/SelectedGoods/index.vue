<template>
  <div class="selectedgoods">
      <div class="test"></div> 
      <!-- <div class="computer"><img :src="goods[0]&&goods[0].productImageBig" alt=""></div>     
      <img @click="jumpHardware" :src="goods[0]&&goods[1].productImageBig" alt="" class="hardware">
      <img :src="goods[0]&&goods[2].productImageBig" alt="" class="netdevice">
      <img :src="goods[0]&&goods[3].productImageBig" alt="" class="phone">
      <img :src="goods[0]&&goods[4].productImageBig" alt="" class="television">      -->
  </div>
</template>
<script>
// 数据交互
export default {
    name:'SelectedGoods',
    data(){
        return{
            goods:[]
           
        }
    },
    methods:{
        jumpHardware(){
             this.$router.replace('/Home/AllGoods');
        }
    },
    
    async created(){
         
        try {
            const res=await this.$http.get('/Selected');
            let goodsData=res.data;
            this.goods=goodsData.result.data;

             
            
        } catch (error) {
            console.log(error.message)
        }
    },
}
</script>
<style scoped lang="scss">
@keyframes move {
        0%{width:500px;}
        100%{width:700px;}     
}
.test{
    width:300px;
    height:300px;
    background-color: red;
    animation: 4s move;
}
    

// .computer{
//     margin-top: 50px;
//     box-shadow: 10px 10px 50px rgba(53,73,94,.5); 
//     width:1100px;
//     height:560px;
//     border-radius: 20px;
//     overflow: hidden;
    
    
    
//     img{
//         width:1100px;
//         border-radius: 20px;
        
       
//     }
//     img:hover{
        
        
        
//     }
   
    
// }




</style>