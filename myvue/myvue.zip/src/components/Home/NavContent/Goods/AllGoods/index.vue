<template>
    <div class="allgoods">
        <slides></slides>
        <h1>全部商品</h1>
        
    </div>
</template>

<script>
import Slides from "./Slides.vue";

export default {
    name: "AllGoods",
    data() {
        return {
            goods: [],
        };
    },

    async created() {
        try {
            const res = await this.$http.get("/Selected");
            console.log(res);
            let goodsData = res.data;
            this.goods = goodsData.result.data;
        } catch (error) {
            console.log(error.message);
        }
    },
    components: { Slides },
};
</script>

<style>
</style>