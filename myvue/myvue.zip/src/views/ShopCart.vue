<template>
  <div class="ShopCart">
      <h1>购物车{{test[1]}}</h1>
      {{test[0]}}
      <ul>
          <li v-for="(item,index) in goodsList" :key=index>
              <img :src="item.productImageBig" alt="">
              <p>{{item.productName}}</p>
          </li>
      </ul>
  </div>
</template>

<script>
export default {
    name:'ShopCart',
    computed:{
        test(){
            return this.$store.state.test
        },
        goodsList(){
            return this.$store.state.list
        },
        goodsNum(){
            return this.$store.state.num
        }
        
    }

}
</script>

<style>

</style>