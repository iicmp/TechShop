<template>
  <div class="ShopCart">
      <h1>ShopCart</h1>
  </div>
</template>

<script>
export default {
    name:'ShopCart'

}
</script>

<style>

</style>